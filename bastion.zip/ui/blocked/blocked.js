// src/shared/types.ts
var CONTROL_TYPES = [
  "time-limit",
  "nav-frequency",
  "degradation",
  "speed-bump"
];

// src/ui/blocked/blocked.ts
var params = new URLSearchParams(window.location.search);
var reasonEl = document.getElementById("reason");
var resetEl = document.getElementById("reset-info");
var bypassSection = document.getElementById("bypass-section");
if (reasonEl) {
  reasonEl.textContent = params.get("reason") || "You set a limit for this site.";
}
var resetsAtStr = params.get("resetsAt");
if (resetEl && resetsAtStr) {
  let updateResetCountdown = function() {
    const remaining = resetsAt - Date.now();
    if (remaining <= 0) {
      resetEl.textContent = "Access should be available now. Try refreshing.";
      return;
    }
    const minutes = Math.ceil(remaining / 6e4);
    const resetTime = new Date(resetsAt).toLocaleTimeString(void 0, {
      hour: "numeric",
      minute: "2-digit"
    });
    resetEl.textContent = `Access resets in ~${minutes}m (at ${resetTime})`;
    setTimeout(updateResetCountdown, 1e4);
  };
  updateResetCountdown2 = updateResetCountdown;
  const resetsAt = parseInt(resetsAtStr, 10);
  updateResetCountdown();
}
var updateResetCountdown2;
var bypassAllowed = params.get("bypassAllowed") === "true";
var bypassRemaining = parseInt(params.get("bypassRemaining") || "0", 10);
var bypassDuration = parseInt(params.get("bypassDuration") || "5", 10);
var domain = params.get("domain") || "";
var controlType = params.get("controlType") || "";
var isValidControlType = CONTROL_TYPES.includes(controlType);
var originalUrl = params.get("originalUrl") || "";
if (bypassSection && bypassAllowed && bypassRemaining > 0 && isValidControlType) {
  const info = document.createElement("p");
  info.className = "bypass-info";
  info.textContent = `${bypassRemaining} bypass${bypassRemaining !== 1 ? "es" : ""} remaining (${bypassDuration}m each)`;
  const btn = document.createElement("button");
  btn.id = "bypass-btn";
  btn.textContent = `Use bypass (${bypassDuration}m)`;
  btn.addEventListener("click", () => {
    btn.disabled = true;
    btn.textContent = "Activating...";
    const msg = {
      type: "activate-bypass",
      domain,
      controlType,
      durationMinutes: bypassDuration
    };
    chrome.runtime.sendMessage(msg, () => {
      if (originalUrl) {
        window.location.href = originalUrl;
      } else {
        history.back();
      }
    });
  });
  bypassSection.appendChild(info);
  bypassSection.appendChild(btn);
} else if (bypassSection && params.has("bypassAllowed")) {
  const info = document.createElement("p");
  info.className = "bypass-info bypass-exhausted";
  info.textContent = "No bypasses remaining.";
  bypassSection.appendChild(info);
}
//# sourceMappingURL=blocked.js.map
