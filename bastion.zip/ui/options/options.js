// src/shared/types.ts
var CONTROL_TYPES = [
  "time-limit",
  "nav-frequency",
  "degradation",
  "speed-bump"
];
var CONFIG_EXPORT_VERSION = 1;
function isValidDomainPattern(pattern) {
  const trimmed = pattern.trim().toLowerCase();
  if (!trimmed) return false;
  const domain = trimmed.startsWith("*.") ? trimmed.slice(2) : trimmed;
  return domain.includes(".") && !domain.startsWith(".") && !domain.endsWith(".");
}

// src/shared/constants.ts
var STORAGE_KEYS = {
  SITE_CONFIGS: "bastion_site_configs",
  TRACKING: "bastion_tracking",
  ACTIVE_SESSION: "bastion_active_session",
  SPEED_BUMP_CLEARANCES: "bastion_speed_bump_clearances"
};
var HEARTBEAT_INTERVAL_MINUTES = 1;
var ORPHAN_SESSION_THRESHOLD_MS = HEARTBEAT_INTERVAL_MINUTES * 2 * 6e4;

// src/storage/settings.ts
async function loadSiteConfigs() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.SITE_CONFIGS);
  return result[STORAGE_KEYS.SITE_CONFIGS] ?? [];
}
async function saveSiteConfigs(configs) {
  await chrome.storage.local.set({ [STORAGE_KEYS.SITE_CONFIGS]: configs });
}

// src/storage/portability.ts
function buildExport(configs) {
  return {
    version: CONFIG_EXPORT_VERSION,
    exportedAt: Date.now(),
    siteConfigs: configs
  };
}
function exportToJson(data) {
  return JSON.stringify(data, null, 2);
}
function exportToEncodedString(data) {
  return toBase64Url(JSON.stringify(data));
}
function importFromJson(json) {
  let parsed;
  try {
    parsed = JSON.parse(json);
  } catch {
    return { ok: false, error: "Invalid JSON" };
  }
  return validateAndReturn(parsed);
}
function importFromEncodedString(encoded) {
  let json;
  try {
    json = fromBase64Url(encoded.trim());
  } catch {
    return { ok: false, error: "Invalid encoded string" };
  }
  return importFromJson(json);
}
function toBase64Url(str) {
  const b64 = btoa(
    String.fromCodePoint(
      ...new TextEncoder().encode(str)
    )
  );
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function fromBase64Url(b64) {
  let standard = b64.replace(/-/g, "+").replace(/_/g, "/");
  const pad = (4 - standard.length % 4) % 4;
  standard += "=".repeat(pad);
  const binary = atob(standard);
  const bytes = Uint8Array.from(binary, (c) => c.codePointAt(0));
  return new TextDecoder().decode(bytes);
}
function validateAndReturn(data) {
  const result = validateExport(data);
  if (!result.valid) {
    return { ok: false, error: result.errors.join("; ") };
  }
  return { ok: true, data };
}
function validateExport(data) {
  const errors = [];
  if (typeof data !== "object" || data === null || Array.isArray(data)) {
    return { valid: false, errors: ["Expected an object"] };
  }
  const obj = data;
  if (obj.version !== CONFIG_EXPORT_VERSION) {
    errors.push(
      `Unsupported version: ${String(obj.version)} (expected ${CONFIG_EXPORT_VERSION})`
    );
  }
  if (typeof obj.exportedAt !== "number") {
    errors.push("Missing or invalid exportedAt timestamp");
  }
  if (!Array.isArray(obj.siteConfigs)) {
    errors.push("Missing or invalid siteConfigs array");
  } else {
    for (let i = 0; i < obj.siteConfigs.length; i++) {
      const siteErrors = validateSiteConfig(obj.siteConfigs[i]);
      for (const err of siteErrors) {
        errors.push(`siteConfigs[${i}]: ${err}`);
      }
    }
  }
  return errors.length === 0 ? { valid: true } : { valid: false, errors };
}
function validateSiteConfig(data) {
  const errors = [];
  if (typeof data !== "object" || data === null || Array.isArray(data)) {
    return ["Expected an object"];
  }
  const obj = data;
  if (typeof obj.id !== "string") {
    errors.push("Missing or invalid id");
  }
  if (typeof obj.domainPattern !== "string") {
    errors.push("Missing or invalid domainPattern");
  }
  if (typeof obj.enabled !== "boolean") {
    errors.push("Missing or invalid enabled field");
  }
  if (!Array.isArray(obj.controls)) {
    errors.push("Missing or invalid controls array");
  } else {
    for (let i = 0; i < obj.controls.length; i++) {
      const controlErrors = validateControlConfig(obj.controls[i]);
      for (const err of controlErrors) {
        errors.push(`controls[${i}]: ${err}`);
      }
    }
  }
  return errors;
}
function validateControlConfig(data) {
  const errors = [];
  if (typeof data !== "object" || data === null || Array.isArray(data)) {
    return ["Expected an object"];
  }
  const obj = data;
  if (typeof obj.enabled !== "boolean") {
    errors.push("Missing or invalid enabled field");
  }
  if (!CONTROL_TYPES.includes(obj.type)) {
    errors.push(`Unknown control type: ${String(obj.type)}`);
    return errors;
  }
  switch (obj.type) {
    case "time-limit":
      if (typeof obj.maxMinutes !== "number") errors.push("Missing maxMinutes");
      if (typeof obj.windowMinutes !== "number") errors.push("Missing windowMinutes");
      break;
    case "nav-frequency":
      if (typeof obj.maxNavigations !== "number") errors.push("Missing maxNavigations");
      if (typeof obj.windowMinutes !== "number") errors.push("Missing windowMinutes");
      break;
    case "degradation":
      if (obj.effect !== "grayscale") errors.push("Missing or invalid effect");
      if (typeof obj.trigger !== "object" || obj.trigger === null) {
        errors.push("Missing trigger");
      }
      break;
    case "speed-bump":
      if (typeof obj.delaySeconds !== "number") errors.push("Missing delaySeconds");
      break;
  }
  if (obj.bypass !== void 0) {
    if (typeof obj.bypass !== "object" || obj.bypass === null || Array.isArray(obj.bypass)) {
      errors.push("bypass must be an object");
    } else {
      const bp = obj.bypass;
      if (typeof bp.maxBypasses !== "number") {
        errors.push("bypass.maxBypasses must be a number");
      }
      if (typeof bp.windowMinutes !== "number") {
        errors.push("bypass.windowMinutes must be a number");
      }
      if (typeof bp.bypassDurationMinutes !== "number") {
        errors.push("bypass.bypassDurationMinutes must be a number");
      }
    }
  }
  return errors;
}
function mergeConfigs(existing, incoming) {
  const incomingWithIds = regenerateIds(incoming);
  const incomingDomains = new Set(
    incomingWithIds.map((c) => c.domainPattern.toLowerCase())
  );
  const kept = existing.filter(
    (c) => !incomingDomains.has(c.domainPattern.toLowerCase())
  );
  return [...kept, ...incomingWithIds];
}
function regenerateIds(configs) {
  return configs.map((c) => ({
    ...structuredClone(c),
    id: crypto.randomUUID()
  }));
}

// src/ui/options/options.ts
var siteConfigs = [];
var saveTimeout = null;
var sitesList = document.getElementById("sites-list");
var addSiteBtn = document.getElementById("add-site");
var siteTemplate = document.getElementById("site-card-template");
var controlTemplate = document.getElementById("control-card-template");
var saveIndicator = document.createElement("div");
saveIndicator.className = "save-indicator";
saveIndicator.textContent = "Saved";
document.body.appendChild(saveIndicator);
function showSaved() {
  saveIndicator.classList.add("visible");
  setTimeout(() => saveIndicator.classList.remove("visible"), 1500);
}
function scheduleSave() {
  if (saveTimeout) clearTimeout(saveTimeout);
  saveTimeout = setTimeout(async () => {
    await saveSiteConfigs(siteConfigs);
    showSaved();
  }, 500);
}
function genId() {
  return crypto.randomUUID();
}
function defaultControl(type) {
  switch (type) {
    case "time-limit":
      return { type: "time-limit", enabled: true, maxMinutes: 30, windowMinutes: 120 };
    case "nav-frequency":
      return { type: "nav-frequency", enabled: true, maxNavigations: 3, windowMinutes: 60 };
    case "degradation":
      return {
        type: "degradation",
        enabled: true,
        effect: "grayscale",
        trigger: { type: "time-of-day", afterHour: 21 }
      };
    case "speed-bump":
      return { type: "speed-bump", enabled: true, delaySeconds: 10 };
  }
}
function renderControlFields(container, config) {
  container.innerHTML = "";
  switch (config.type) {
    case "time-limit":
      container.appendChild(durationRow("Max time", config.maxMinutes, (m) => {
        config.maxMinutes = m;
        scheduleSave();
      }));
      container.appendChild(durationRow("Per window", config.windowMinutes, (m) => {
        config.windowMinutes = m;
        scheduleSave();
      }));
      break;
    case "nav-frequency":
      container.appendChild(fieldRow("Max visits", "number", String(config.maxNavigations), (v) => {
        config.maxNavigations = parseInt(v, 10) || 1;
        scheduleSave();
      }));
      container.appendChild(durationRow("Per window", config.windowMinutes, (m) => {
        config.windowMinutes = m;
        scheduleSave();
      }));
      break;
    case "degradation": {
      const triggerRow = document.createElement("div");
      triggerRow.className = "field-row";
      const triggerLabel = document.createElement("label");
      triggerLabel.textContent = "Trigger";
      const triggerSelect = document.createElement("select");
      triggerSelect.innerHTML = `
        <option value="time-of-day">Time of day</option>
        <option value="time-on-site">Time on site</option>
      `;
      triggerSelect.value = config.trigger.type;
      triggerRow.appendChild(triggerLabel);
      triggerRow.appendChild(triggerSelect);
      container.appendChild(triggerRow);
      const detailContainer = document.createElement("div");
      container.appendChild(detailContainer);
      const renderTriggerFields = () => {
        detailContainer.innerHTML = "";
        const dc = config;
        if (dc.trigger.type === "time-of-day") {
          detailContainer.appendChild(fieldRow("After hour (0-23)", "number", String(dc.trigger.afterHour), (v) => {
            dc.trigger = { type: "time-of-day", afterHour: parseInt(v, 10) || 0 };
            scheduleSave();
          }));
        } else {
          detailContainer.appendChild(durationRow("After on site", dc.trigger.afterMinutes, (m) => {
            dc.trigger = { type: "time-on-site", afterMinutes: m };
            scheduleSave();
          }));
        }
      };
      triggerSelect.addEventListener("change", () => {
        const dc = config;
        if (triggerSelect.value === "time-of-day") {
          dc.trigger = { type: "time-of-day", afterHour: 21 };
        } else {
          dc.trigger = { type: "time-on-site", afterMinutes: 10 };
        }
        renderTriggerFields();
        scheduleSave();
      });
      renderTriggerFields();
      break;
    }
    case "speed-bump":
      container.appendChild(fieldRow("Delay (seconds)", "number", String(config.delaySeconds), (v) => {
        config.delaySeconds = parseInt(v, 10) || 1;
        scheduleSave();
      }));
      break;
  }
}
function fieldRow(label, type, value, onChange) {
  const row = document.createElement("div");
  row.className = "field-row";
  const lbl = document.createElement("label");
  lbl.textContent = label;
  const input = document.createElement("input");
  input.type = type;
  input.value = value;
  if (type === "number") input.min = "0";
  input.addEventListener("input", () => onChange(input.value));
  row.appendChild(lbl);
  row.appendChild(input);
  return row;
}
function durationRow(label, totalMinutes, onChange) {
  const row = document.createElement("div");
  row.className = "field-row";
  const lbl = document.createElement("label");
  lbl.textContent = label;
  row.appendChild(lbl);
  const wrapper = document.createElement("div");
  wrapper.className = "duration-input";
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  const hoursInput = document.createElement("input");
  hoursInput.type = "number";
  hoursInput.min = "0";
  hoursInput.value = String(hours);
  const hoursUnit = document.createElement("span");
  hoursUnit.className = "unit";
  hoursUnit.textContent = "h";
  const minsInput = document.createElement("input");
  minsInput.type = "number";
  minsInput.min = "0";
  minsInput.max = "59";
  minsInput.value = String(mins);
  const minsUnit = document.createElement("span");
  minsUnit.className = "unit";
  minsUnit.textContent = "m";
  const emitChange = () => {
    const h = parseInt(hoursInput.value, 10) || 0;
    const m = parseInt(minsInput.value, 10) || 0;
    const total = Math.max(1, h * 60 + m);
    onChange(total);
  };
  hoursInput.addEventListener("input", emitChange);
  minsInput.addEventListener("input", emitChange);
  wrapper.appendChild(hoursInput);
  wrapper.appendChild(hoursUnit);
  wrapper.appendChild(minsInput);
  wrapper.appendChild(minsUnit);
  row.appendChild(wrapper);
  return row;
}
function renderControlCard(siteConfig, controlIndex) {
  const frag = controlTemplate.content.cloneNode(true);
  const card = frag.querySelector(".control-card");
  const getConfig = () => siteConfig.controls[controlIndex];
  const typeSelect = card.querySelector(".control-type");
  typeSelect.value = getConfig().type;
  typeSelect.addEventListener("change", () => {
    const newType = typeSelect.value;
    const oldConfig = getConfig();
    const newConfig = defaultControl(newType);
    newConfig.enabled = oldConfig.enabled;
    newConfig.bypass = newType === "degradation" ? void 0 : oldConfig.bypass;
    siteConfig.controls[controlIndex] = newConfig;
    renderAllSites();
    scheduleSave();
  });
  const enabledToggle = card.querySelector(".control-enabled");
  enabledToggle.checked = getConfig().enabled;
  enabledToggle.addEventListener("change", () => {
    getConfig().enabled = enabledToggle.checked;
    scheduleSave();
  });
  card.querySelector(".btn-delete-control").addEventListener("click", () => {
    siteConfig.controls.splice(controlIndex, 1);
    renderAllSites();
    scheduleSave();
  });
  renderControlFields(card.querySelector(".control-fields"), getConfig());
  const bypassSectionEl = card.querySelector(".bypass-section");
  if (getConfig().type === "degradation") {
    bypassSectionEl.style.display = "none";
  }
  const bypassEnabled = card.querySelector(".bypass-enabled");
  const bypassConfigEl = card.querySelector(".bypass-config");
  function renderBypassFields() {
    bypassConfigEl.innerHTML = "";
    const bp = getConfig().bypass;
    if (!bp) return;
    bypassConfigEl.appendChild(fieldRow("Max bypasses", "number", String(bp.maxBypasses), (v) => {
      const cfg = getConfig();
      if (cfg.bypass) {
        cfg.bypass.maxBypasses = parseInt(v, 10) || 1;
        scheduleSave();
      }
    }));
    bypassConfigEl.appendChild(durationRow("Per window", bp.windowMinutes, (m) => {
      const cfg = getConfig();
      if (cfg.bypass) {
        cfg.bypass.windowMinutes = m;
        scheduleSave();
      }
    }));
    bypassConfigEl.appendChild(durationRow("Bypass duration", bp.bypassDurationMinutes, (m) => {
      const cfg = getConfig();
      if (cfg.bypass) {
        cfg.bypass.bypassDurationMinutes = m;
        scheduleSave();
      }
    }));
  }
  const currentBypass = getConfig().bypass;
  if (currentBypass) {
    bypassEnabled.checked = true;
    bypassConfigEl.style.display = "";
    renderBypassFields();
  }
  bypassEnabled.addEventListener("change", () => {
    if (bypassEnabled.checked) {
      bypassConfigEl.style.display = "";
      getConfig().bypass = {
        maxBypasses: 3,
        windowMinutes: 1440,
        bypassDurationMinutes: 5
      };
      renderBypassFields();
    } else {
      bypassConfigEl.style.display = "none";
      bypassConfigEl.innerHTML = "";
      getConfig().bypass = void 0;
    }
    scheduleSave();
  });
  return card;
}
function renderSiteCard(siteConfig) {
  const frag = siteTemplate.content.cloneNode(true);
  const card = frag.querySelector(".site-card");
  const domainInput = card.querySelector(".domain-input");
  domainInput.value = siteConfig.domainPattern;
  domainInput.addEventListener("input", () => {
    const value = domainInput.value.trim();
    siteConfig.domainPattern = value;
    if (value && !isValidDomainPattern(value)) {
      domainInput.style.borderColor = "#e94560";
      domainInput.title = 'Pattern must contain at least one dot (e.g. "reddit.com")';
    } else {
      domainInput.style.borderColor = "";
      domainInput.title = "";
    }
    scheduleSave();
  });
  const enabledToggle = card.querySelector(".site-enabled");
  enabledToggle.checked = siteConfig.enabled;
  enabledToggle.addEventListener("change", () => {
    siteConfig.enabled = enabledToggle.checked;
    scheduleSave();
  });
  card.querySelector(".btn-delete-site").addEventListener("click", () => {
    siteConfigs = siteConfigs.filter((c) => c.id !== siteConfig.id);
    renderAllSites();
    scheduleSave();
  });
  const controlsList = card.querySelector(".controls-list");
  for (let i = 0; i < siteConfig.controls.length; i++) {
    controlsList.appendChild(renderControlCard(siteConfig, i));
  }
  card.querySelector(".btn-add-control").addEventListener("click", () => {
    siteConfig.controls.push(defaultControl("time-limit"));
    renderAllSites();
    scheduleSave();
  });
  return card;
}
function renderAllSites() {
  sitesList.innerHTML = "";
  for (const config of siteConfigs) {
    sitesList.appendChild(renderSiteCard(config));
  }
}
addSiteBtn.addEventListener("click", () => {
  siteConfigs.push({
    id: genId(),
    domainPattern: "",
    controls: [],
    enabled: true
  });
  renderAllSites();
  const inputs = sitesList.querySelectorAll(".domain-input");
  const lastInput = inputs[inputs.length - 1];
  lastInput?.focus();
  scheduleSave();
});
var exportFileBtn = document.getElementById("export-file");
var exportStringBtn = document.getElementById("export-string");
var importFileBtn = document.getElementById("import-file");
var importStringBtn = document.getElementById("import-string");
var importFileInput = document.getElementById("import-file-input");
var portabilityStatus = document.getElementById("portability-status");
var modalTemplate = document.getElementById("modal-template");
var statusTimeout = null;
function showStatus(message, type) {
  portabilityStatus.textContent = message;
  portabilityStatus.className = `portability-status ${type}`;
  if (statusTimeout) clearTimeout(statusTimeout);
  statusTimeout = setTimeout(() => {
    portabilityStatus.textContent = "";
    portabilityStatus.className = "portability-status";
  }, 5e3);
}
function showModal(opts) {
  const frag = modalTemplate.content.cloneNode(true);
  const backdrop = frag.querySelector(".modal-backdrop");
  const msgEl = backdrop.querySelector(".modal-message");
  const bodyEl = backdrop.querySelector(".modal-body");
  const actionsEl = backdrop.querySelector(".modal-actions");
  msgEl.textContent = opts.message;
  if (opts.body) {
    opts.body(bodyEl);
  }
  const close = () => backdrop.remove();
  backdrop.addEventListener("click", (e) => {
    if (e.target === backdrop) close();
  });
  for (const btn of opts.buttons) {
    const button = document.createElement("button");
    button.textContent = btn.label;
    button.className = btn.className;
    button.addEventListener("click", () => btn.onClick(close));
    actionsEl.appendChild(button);
  }
  document.body.appendChild(backdrop);
  return backdrop;
}
function importModeRadios(container) {
  const wrapper = document.createElement("div");
  wrapper.className = "import-mode";
  const makeRadio = (value, label, checked) => {
    const lbl = document.createElement("label");
    const input = document.createElement("input");
    input.type = "radio";
    input.name = "import-mode";
    input.value = value;
    input.checked = checked;
    lbl.appendChild(input);
    lbl.appendChild(document.createTextNode(label));
    wrapper.appendChild(lbl);
  };
  makeRadio("replace", "Replace all", true);
  makeRadio("merge", "Merge (incoming wins)", false);
  container.appendChild(wrapper);
  return () => {
    const selected = wrapper.querySelector("input:checked");
    return selected?.value ?? "replace";
  };
}
function pluralSite(count) {
  return `${count} site config${count !== 1 ? "s" : ""}`;
}
async function applyImport(data, mode) {
  if (mode === "merge") {
    siteConfigs = mergeConfigs(siteConfigs, data.siteConfigs);
  } else {
    siteConfigs = regenerateIds(data.siteConfigs);
  }
  await saveSiteConfigs(siteConfigs);
  renderAllSites();
  showStatus(`Imported ${pluralSite(data.siteConfigs.length)} (${mode})`, "success");
}
function showImportConfirm(data) {
  let getMode;
  showModal({
    message: `Import ${pluralSite(data.siteConfigs.length)}? You currently have ${pluralSite(siteConfigs.length)}.`,
    body: (container) => {
      getMode = importModeRadios(container);
    },
    buttons: [
      { label: "Cancel", className: "btn-modal-cancel", onClick: (close) => close() },
      {
        label: "Import",
        className: "btn-modal-confirm",
        onClick: (close) => {
          close();
          applyImport(data, getMode());
        }
      }
    ]
  });
}
exportFileBtn.addEventListener("click", () => {
  const data = buildExport(siteConfigs);
  const json = exportToJson(data);
  const blob = new Blob([json], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `bastion-config-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
  showStatus("Config exported as file", "success");
});
exportStringBtn.addEventListener("click", () => {
  const data = buildExport(siteConfigs);
  const encoded = exportToEncodedString(data);
  showModal({
    message: "Copy this string to share your config:",
    body: (container) => {
      const textarea = document.createElement("textarea");
      textarea.rows = 4;
      textarea.readOnly = true;
      textarea.value = encoded;
      container.appendChild(textarea);
      textarea.addEventListener("focus", () => textarea.select());
      setTimeout(() => textarea.focus(), 50);
    },
    buttons: [
      {
        label: "Copy",
        className: "btn-modal-confirm",
        onClick: (close) => {
          navigator.clipboard.writeText(encoded).then(
            () => {
              close();
              showStatus("Copied to clipboard", "success");
            },
            () => showStatus("Failed to copy - please select and copy manually", "error")
          );
        }
      },
      { label: "Close", className: "btn-modal-cancel", onClick: (close) => close() }
    ]
  });
});
importFileBtn.addEventListener("click", () => {
  importFileInput.value = "";
  importFileInput.click();
});
importFileInput.addEventListener("change", () => {
  const file = importFileInput.files?.[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const result = importFromJson(reader.result);
    if (!result.ok) {
      showStatus(result.error, "error");
      return;
    }
    showImportConfirm(result.data);
  };
  reader.readAsText(file);
});
importStringBtn.addEventListener("click", () => {
  let textarea;
  let errorEl;
  showModal({
    message: "Paste your encoded config string:",
    body: (container) => {
      textarea = document.createElement("textarea");
      textarea.rows = 4;
      textarea.placeholder = "Paste encoded string here...";
      container.appendChild(textarea);
      errorEl = document.createElement("div");
      errorEl.className = "modal-error";
      container.appendChild(errorEl);
      setTimeout(() => textarea.focus(), 50);
    },
    buttons: [
      { label: "Cancel", className: "btn-modal-cancel", onClick: (close) => close() },
      {
        label: "Import",
        className: "btn-modal-confirm",
        onClick: (close) => {
          const value = textarea.value.trim();
          if (!value) {
            errorEl.textContent = "Please paste a config string";
            return;
          }
          const result = importFromEncodedString(value);
          if (!result.ok) {
            errorEl.textContent = result.error;
            return;
          }
          close();
          showImportConfirm(result.data);
        }
      }
    ]
  });
});
async function init() {
  siteConfigs = await loadSiteConfigs();
  renderAllSites();
}
init();
//# sourceMappingURL=options.js.map
