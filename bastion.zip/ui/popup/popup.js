// src/shared/constants.ts
var STORAGE_KEYS = {
  SITE_CONFIGS: "bastion_site_configs",
  TRACKING: "bastion_tracking",
  ACTIVE_SESSION: "bastion_active_session",
  SPEED_BUMP_CLEARANCES: "bastion_speed_bump_clearances"
};
var HEARTBEAT_INTERVAL_MINUTES = 1;
var ORPHAN_SESSION_THRESHOLD_MS = HEARTBEAT_INTERVAL_MINUTES * 2 * 6e4;

// src/storage/settings.ts
async function loadSiteConfigs() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.SITE_CONFIGS);
  return result[STORAGE_KEYS.SITE_CONFIGS] ?? [];
}
async function saveSiteConfigs(configs) {
  await chrome.storage.local.set({ [STORAGE_KEYS.SITE_CONFIGS]: configs });
}

// src/shared/time-utils.ts
function minutesToMs(minutes) {
  return minutes * 6e4;
}
function totalTimeInWindow(entries, windowMinutes, now) {
  const windowStartMs = now - minutesToMs(windowMinutes);
  let totalMs = 0;
  for (const entry of entries) {
    if (entry.end <= windowStartMs) continue;
    const effectiveStart = Math.max(entry.start, windowStartMs);
    const effectiveEnd = Math.min(entry.end, now);
    totalMs += Math.max(0, effectiveEnd - effectiveStart);
  }
  return totalMs / 6e4;
}
function countNavsInWindow(entries, windowMinutes, now) {
  const windowStartMs = now - minutesToMs(windowMinutes);
  return entries.filter((e) => e.timestamp >= windowStartMs).length;
}
function formatDuration(minutes) {
  if (minutes < 1) {
    const seconds = Math.round(minutes * 60);
    return `${seconds}s`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  if (hours > 0 && mins > 0) return `${hours}h ${mins}m`;
  if (hours > 0) return `${hours}h`;
  return `${mins}m`;
}

// src/storage/schema.ts
function emptySiteTrackingData() {
  return {
    timeEntries: [],
    navEntries: [],
    bypasses: {}
  };
}

// src/storage/tracking.ts
var writeQueue = Promise.resolve();
async function loadTrackingStoreRaw() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.TRACKING);
  return result[STORAGE_KEYS.TRACKING] ?? {};
}
async function loadTrackingStore() {
  return loadTrackingStoreRaw();
}
function hasActiveBypass(data, controlType, now) {
  const entries = data.bypasses[controlType];
  if (!entries) return false;
  return entries.some((e) => e.expiresAt > now);
}

// src/ui/popup/popup.ts
var sitesSummary = document.getElementById("sites-summary");
function openOptions() {
  chrome.runtime.openOptionsPage();
}
document.getElementById("open-options")?.addEventListener("click", (e) => {
  e.preventDefault();
  openOptions();
});
document.getElementById("open-options-empty")?.addEventListener("click", (e) => {
  e.preventDefault();
  openOptions();
});
async function render() {
  const configs = await loadSiteConfigs();
  const trackingStore = await loadTrackingStore();
  const now = Date.now();
  if (configs.length === 0) {
    document.body.classList.add("empty");
    return;
  }
  document.body.classList.remove("empty");
  sitesSummary.innerHTML = "";
  for (const config of configs) {
    const tracking = trackingStore[config.domainPattern] ?? emptySiteTrackingData();
    sitesSummary.appendChild(renderSiteSummary(config, tracking, now, configs));
  }
}
function renderSiteSummary(config, tracking, now, allConfigs) {
  const card = document.createElement("div");
  card.className = `site-summary${config.enabled ? "" : " disabled"}`;
  const header = document.createElement("div");
  header.className = "site-summary-header";
  const domain = document.createElement("span");
  domain.className = "site-domain";
  domain.textContent = config.domainPattern || "(no domain)";
  const toggle = document.createElement("label");
  toggle.className = "site-toggle";
  const checkbox = document.createElement("input");
  checkbox.type = "checkbox";
  checkbox.checked = config.enabled;
  checkbox.addEventListener("change", async () => {
    config.enabled = checkbox.checked;
    await saveSiteConfigs(allConfigs);
    render();
  });
  const slider = document.createElement("span");
  slider.className = "slider";
  toggle.appendChild(checkbox);
  toggle.appendChild(slider);
  header.appendChild(domain);
  header.appendChild(toggle);
  card.appendChild(header);
  if (config.enabled && config.controls.length > 0) {
    const pillsRow = document.createElement("div");
    pillsRow.className = "controls-status";
    for (const control of config.controls) {
      if (!control.enabled) continue;
      const pill = document.createElement("span");
      pill.className = "control-pill";
      pill.textContent = controlLabel(control);
      const bypassed = hasActiveBypass(tracking, control.type, now);
      if (bypassed) {
        pill.classList.add("bypassed");
        pill.textContent += " (bypassed)";
      } else if (isControlTriggered(control, tracking, now)) {
        pill.classList.add("blocked");
      } else {
        pill.classList.add("active");
      }
      pillsRow.appendChild(pill);
    }
    card.appendChild(pillsRow);
    const stats = buildStats(config, tracking, now);
    if (stats) {
      const statsRow = document.createElement("div");
      statsRow.className = "stats-row";
      statsRow.textContent = stats;
      card.appendChild(statsRow);
    }
  }
  return card;
}
function controlLabel(control) {
  switch (control.type) {
    case "time-limit":
      return "Time";
    case "nav-frequency":
      return "Visits";
    case "degradation":
      return "Grayscale";
    case "speed-bump":
      return "Bump";
  }
}
function isControlTriggered(control, tracking, now) {
  switch (control.type) {
    case "time-limit": {
      const used = totalTimeInWindow(tracking.timeEntries, control.windowMinutes, now);
      return used >= control.maxMinutes;
    }
    case "nav-frequency": {
      const count = countNavsInWindow(tracking.navEntries, control.windowMinutes, now);
      return count >= control.maxNavigations;
    }
    default:
      return false;
  }
}
function buildStats(config, tracking, now) {
  const parts = [];
  const timeControl = config.controls.find(
    (c) => c.type === "time-limit" && c.enabled
  );
  if (timeControl && timeControl.type === "time-limit") {
    const used = totalTimeInWindow(tracking.timeEntries, timeControl.windowMinutes, now);
    parts.push(`${formatDuration(used)} / ${formatDuration(timeControl.maxMinutes)}`);
  }
  const navControl = config.controls.find(
    (c) => c.type === "nav-frequency" && c.enabled
  );
  if (navControl && navControl.type === "nav-frequency") {
    const count = countNavsInWindow(tracking.navEntries, navControl.windowMinutes, now);
    parts.push(`${count} / ${navControl.maxNavigations} visits`);
  }
  return parts.length > 0 ? parts.join(" | ") : null;
}
render();
//# sourceMappingURL=popup.js.map
