// src/ui/speed-bump/speed-bump.ts
var params = new URLSearchParams(window.location.search);
var targetUrl = params.get("url");
var delay = parseInt(params.get("delay") || "10", 10);
var domain = params.get("domain") || "this site";
var messageEl = document.getElementById("message");
var countdownEl = document.getElementById("countdown");
var proceedBtn = document.getElementById("proceed");
if (!targetUrl) {
  if (messageEl) {
    messageEl.textContent = "Something went wrong - no target URL was provided.";
  }
  if (countdownEl) {
    countdownEl.style.display = "none";
  }
} else {
  let updateCountdown = function() {
    if (countdownEl) {
      countdownEl.textContent = String(remaining);
    }
    if (remaining <= 0 && proceedBtn) {
      proceedBtn.disabled = false;
    } else {
      remaining--;
      setTimeout(updateCountdown, 1e3);
    }
  };
  updateCountdown2 = updateCountdown;
  if (messageEl) {
    messageEl.textContent = `Taking a moment before visiting ${domain}...`;
  }
  let remaining = delay;
  updateCountdown();
  if (proceedBtn) {
    proceedBtn.addEventListener("click", () => {
      const msg = {
        type: "speed-bump-cleared",
        domain
      };
      chrome.runtime.sendMessage(msg, () => {
        window.location.href = targetUrl;
      });
    });
  }
}
var updateCountdown2;
//# sourceMappingURL=speed-bump.js.map
