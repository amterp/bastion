// src/content/degradation.ts
var GRAYSCALE_STYLE_ID = "bastion-grayscale";
function applyGrayscale() {
  if (document.getElementById(GRAYSCALE_STYLE_ID)) return;
  const style = document.createElement("style");
  style.id = GRAYSCALE_STYLE_ID;
  style.textContent = "html { filter: grayscale(100%) !important; }";
  document.head.appendChild(style);
}
function removeGrayscale() {
  const style = document.getElementById(GRAYSCALE_STYLE_ID);
  if (style) style.remove();
}
function checkDegradation() {
  const msg = {
    type: "check-degradation",
    url: window.location.href
  };
  chrome.runtime.sendMessage(msg, (response) => {
    if (chrome.runtime.lastError) return;
    if (response?.degrade && response.effect === "grayscale") {
      applyGrayscale();
    } else {
      removeGrayscale();
    }
  });
}
checkDegradation();
setInterval(checkDegradation, 3e4);
//# sourceMappingURL=degradation.js.map
