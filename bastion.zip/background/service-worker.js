// src/controls/registry.ts
var registry = /* @__PURE__ */ new Map();
function registerControl(evaluator) {
  registry.set(evaluator.type, evaluator);
}
function getEvaluator(type) {
  return registry.get(type);
}

// src/shared/time-utils.ts
function minutesToMs(minutes) {
  return minutes * 6e4;
}
function totalTimeInWindow(entries, windowMinutes, now) {
  const windowStartMs = now - minutesToMs(windowMinutes);
  let totalMs = 0;
  for (const entry of entries) {
    if (entry.end <= windowStartMs) continue;
    const effectiveStart = Math.max(entry.start, windowStartMs);
    const effectiveEnd = Math.min(entry.end, now);
    totalMs += Math.max(0, effectiveEnd - effectiveStart);
  }
  return totalMs / 6e4;
}
function countNavsInWindow(entries, windowMinutes, now) {
  const windowStartMs = now - minutesToMs(windowMinutes);
  return entries.filter((e) => e.timestamp >= windowStartMs).length;
}
function pruneTimeEntries(entries, maxWindowMinutes, now) {
  const cutoff = now - minutesToMs(maxWindowMinutes);
  return entries.filter((e) => e.end > cutoff);
}
function pruneNavEntries(entries, maxWindowMinutes, now) {
  const cutoff = now - minutesToMs(maxWindowMinutes);
  return entries.filter((e) => e.timestamp > cutoff);
}
function computeResetTime(entries, windowMinutes, maxMinutes, now) {
  const windowMs = minutesToMs(windowMinutes);
  const maxMs = minutesToMs(maxMinutes);
  const windowStart = now - windowMs;
  const inWindow = entries.filter((e) => e.end > windowStart).map((e) => ({
    start: Math.max(e.start, windowStart),
    end: Math.min(e.end, now)
  })).sort((a, b) => a.end - b.end);
  let totalMs = inWindow.reduce((sum, e) => sum + (e.end - e.start), 0);
  for (const entry of inWindow) {
    const entryDuration = entry.end - entry.start;
    totalMs -= entryDuration;
    if (totalMs < maxMs) {
      return entry.end + windowMs;
    }
  }
  return now + windowMs;
}
function computeNavResetTime(entries, windowMinutes, maxNavigations, now) {
  const windowMs = minutesToMs(windowMinutes);
  const windowStart = now - windowMs;
  const inWindow = entries.filter((e) => e.timestamp >= windowStart).map((e) => e.timestamp).sort((a, b) => a - b);
  const excess = inWindow.length - maxNavigations + 1;
  if (excess > 0 && excess <= inWindow.length) {
    return inWindow[excess - 1] + windowMs;
  }
  return now + windowMs;
}
function formatDuration(minutes) {
  if (minutes < 1) {
    const seconds = Math.round(minutes * 60);
    return `${seconds}s`;
  }
  const hours = Math.floor(minutes / 60);
  const mins = Math.round(minutes % 60);
  if (hours > 0 && mins > 0) return `${hours}h ${mins}m`;
  if (hours > 0) return `${hours}h`;
  return `${mins}m`;
}

// src/controls/time-limit/evaluator.ts
var timeLimitEvaluator = {
  type: "time-limit",
  evaluate(config, tracking, now) {
    const usedMinutes = totalTimeInWindow(
      tracking.timeEntries,
      config.windowMinutes,
      now
    );
    if (usedMinutes >= config.maxMinutes) {
      const resetsAt = computeResetTime(
        tracking.timeEntries,
        config.windowMinutes,
        config.maxMinutes,
        now
      );
      return {
        type: "time-limit",
        action: "block",
        resetsAt,
        reason: `You've used ${formatDuration(usedMinutes)} of ${formatDuration(config.maxMinutes)} allowed in the last ${formatDuration(config.windowMinutes)}.`
      };
    }
    return { action: "allow" };
  }
};

// src/controls/nav-frequency/evaluator.ts
var navFrequencyEvaluator = {
  type: "nav-frequency",
  evaluate(config, tracking, now) {
    const count = countNavsInWindow(
      tracking.navEntries,
      config.windowMinutes,
      now
    );
    if (count >= config.maxNavigations) {
      const resetsAt = computeNavResetTime(
        tracking.navEntries,
        config.windowMinutes,
        config.maxNavigations,
        now
      );
      return {
        type: "nav-frequency",
        action: "block",
        resetsAt,
        reason: `You've visited this site ${count} times (limit: ${config.maxNavigations}) in the last ${formatDuration(config.windowMinutes)}.`
      };
    }
    return { action: "allow" };
  }
};

// src/controls/speed-bump/evaluator.ts
var speedBumpEvaluator = {
  type: "speed-bump",
  evaluate(config, _tracking, _now) {
    return {
      type: "speed-bump",
      action: "speed-bump",
      delaySeconds: config.delaySeconds
    };
  }
};

// src/controls/degradation/evaluator.ts
var degradationEvaluator = {
  type: "degradation",
  evaluate(config, tracking, now) {
    if (shouldApplyDegradation(config, tracking, now)) {
      return {
        type: "degradation",
        action: "degrade",
        degradeEffect: config.effect
      };
    }
    return { action: "allow" };
  }
};
function shouldApplyDegradation(config, tracking, now) {
  const trigger = config.trigger;
  switch (trigger.type) {
    case "time-of-day": {
      const currentHour = new Date(now).getHours();
      return currentHour >= trigger.afterHour;
    }
    case "time-on-site": {
      const minutesOnSite = totalTimeInWindow(
        tracking.timeEntries,
        24 * 60,
        now
      );
      return minutesOnSite >= trigger.afterMinutes;
    }
    default:
      return false;
  }
}

// src/controls/init.ts
function initControls() {
  registerControl(timeLimitEvaluator);
  registerControl(navFrequencyEvaluator);
  registerControl(speedBumpEvaluator);
  registerControl(degradationEvaluator);
}

// src/shared/constants.ts
var STORAGE_KEYS = {
  SITE_CONFIGS: "bastion_site_configs",
  TRACKING: "bastion_tracking",
  ACTIVE_SESSION: "bastion_active_session",
  SPEED_BUMP_CLEARANCES: "bastion_speed_bump_clearances"
};
var HEARTBEAT_INTERVAL_MINUTES = 1;
var SPEED_BUMP_CLEARANCE_TTL_MS = 3e4;
var ORPHAN_SESSION_THRESHOLD_MS = HEARTBEAT_INTERVAL_MINUTES * 2 * 6e4;
var ALARMS = {
  HEARTBEAT: "bastion-heartbeat"
};

// src/storage/settings.ts
async function loadSiteConfigs() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.SITE_CONFIGS);
  return result[STORAGE_KEYS.SITE_CONFIGS] ?? [];
}

// src/shared/types.ts
function isValidDomainPattern(pattern) {
  const trimmed = pattern.trim().toLowerCase();
  if (!trimmed) return false;
  const domain = trimmed.startsWith("*.") ? trimmed.slice(2) : trimmed;
  return domain.includes(".") && !domain.startsWith(".") && !domain.endsWith(".");
}

// src/shared/url-utils.ts
function extractHostname(url) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
      return null;
    }
    return parsed.hostname;
  } catch {
    return null;
  }
}
function matchesDomainPattern(hostname, pattern) {
  if (!isValidDomainPattern(pattern)) return false;
  const normalizedHost = hostname.toLowerCase();
  const normalizedPattern = pattern.toLowerCase();
  if (normalizedPattern.startsWith("*.")) {
    const baseDomain = normalizedPattern.slice(2);
    return normalizedHost.endsWith("." + baseDomain) && normalizedHost !== baseDomain;
  }
  if (normalizedHost === normalizedPattern) {
    return true;
  }
  return normalizedHost.endsWith("." + normalizedPattern);
}
function findMatchingSiteConfig(url, configs) {
  const hostname = extractHostname(url);
  if (!hostname) return null;
  for (const config of configs) {
    if (config.enabled && matchesDomainPattern(hostname, config.domainPattern)) {
      return config;
    }
  }
  return null;
}
function findMatchingDomainPattern(hostname, configs) {
  for (const config of configs) {
    if (config.enabled && matchesDomainPattern(hostname, config.domainPattern)) {
      return config.domainPattern;
    }
  }
  return null;
}

// src/storage/schema.ts
function emptySiteTrackingData() {
  return {
    timeEntries: [],
    navEntries: [],
    bypasses: {}
  };
}

// src/storage/tracking.ts
var writeQueue = Promise.resolve();
function withTrackingStore(fn) {
  writeQueue = writeQueue.then(async () => {
    const store = await loadTrackingStoreRaw();
    const result = fn(store);
    await saveTrackingStoreRaw(result ?? store);
  });
  return writeQueue;
}
async function loadTrackingStoreRaw() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.TRACKING);
  return result[STORAGE_KEYS.TRACKING] ?? {};
}
async function saveTrackingStoreRaw(store) {
  await chrome.storage.local.set({ [STORAGE_KEYS.TRACKING]: store });
}
async function loadTrackingStore() {
  return loadTrackingStoreRaw();
}
async function getTrackingData(domain) {
  const store = await loadTrackingStoreRaw();
  return store[domain] ?? emptySiteTrackingData();
}
function mutateTrackingData(domain, mutator) {
  return withTrackingStore((store) => {
    if (!store[domain]) {
      store[domain] = emptySiteTrackingData();
    }
    mutator(store[domain]);
  });
}
function saveTrackingStore(store) {
  return saveTrackingStoreRaw(store);
}
async function loadActiveSession() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.ACTIVE_SESSION);
  return result[STORAGE_KEYS.ACTIVE_SESSION] ?? null;
}
async function saveActiveSession(session) {
  await chrome.storage.local.set({ [STORAGE_KEYS.ACTIVE_SESSION]: session });
}
async function clearActiveSession() {
  await chrome.storage.local.remove(STORAGE_KEYS.ACTIVE_SESSION);
}
async function loadClearances() {
  const result = await chrome.storage.local.get(
    STORAGE_KEYS.SPEED_BUMP_CLEARANCES
  );
  return result[STORAGE_KEYS.SPEED_BUMP_CLEARANCES] ?? [];
}
async function saveClearances(clearances) {
  await chrome.storage.local.set({
    [STORAGE_KEYS.SPEED_BUMP_CLEARANCES]: clearances
  });
}
async function addClearance(clearance) {
  const now = Date.now();
  const existing = await loadClearances();
  const valid = existing.filter((c) => c.expiresAt > now);
  valid.push(clearance);
  await saveClearances(valid);
}
async function hasClearance(domain) {
  const now = Date.now();
  const clearances = await loadClearances();
  return clearances.some((c) => c.domain === domain && c.expiresAt > now);
}
function recordBypass(domain, controlType, durationMinutes) {
  const now = Date.now();
  return mutateTrackingData(domain, (data) => {
    if (!data.bypasses[controlType]) {
      data.bypasses[controlType] = [];
    }
    data.bypasses[controlType].push({
      timestamp: now,
      expiresAt: now + minutesToMs(durationMinutes)
    });
  });
}
function hasActiveBypass(data, controlType, now) {
  const entries = data.bypasses[controlType];
  if (!entries) return false;
  return entries.some((e) => e.expiresAt > now);
}
function countBypassesInWindow(data, controlType, windowMinutes, now) {
  const entries = data.bypasses[controlType];
  if (!entries) return 0;
  const windowStart = now - minutesToMs(windowMinutes);
  return entries.filter((e) => e.timestamp >= windowStart).length;
}

// src/controls/types.ts
var ACTION_PRIORITY = {
  allow: 0,
  degrade: 1,
  "speed-bump": 2,
  block: 3
};

// src/controls/evaluate.ts
var ALLOW = { action: "allow" };
function evaluateControls(siteConfig, tracking, now) {
  let mostRestrictive = ALLOW;
  for (const control of siteConfig.controls) {
    if (!control.enabled) continue;
    if (hasActiveBypass(tracking, control.type, now)) continue;
    const evaluator = getEvaluator(control.type);
    if (!evaluator) continue;
    const result = evaluator.evaluate(control, tracking, now);
    if (ACTION_PRIORITY[result.action] > ACTION_PRIORITY[mostRestrictive.action]) {
      mostRestrictive = result;
    }
  }
  return mostRestrictive;
}

// src/background/navigation-handler.ts
async function handleNavigation(url, configs) {
  const siteConfig = findMatchingSiteConfig(url, configs);
  if (!siteConfig) return null;
  const tracking = await getTrackingData(siteConfig.domainPattern);
  const now = Date.now();
  const result = evaluateControls(siteConfig, tracking, now);
  if (result.action === "allow") return null;
  let bypassInfo = null;
  if (result.action === "block") {
    const blockingControl = siteConfig.controls.find(
      (c) => c.type === result.type && c.enabled && c.bypass
    );
    if (blockingControl?.bypass) {
      const bp = blockingControl.bypass;
      const used = countBypassesInWindow(tracking, result.type, bp.windowMinutes, now);
      const remaining = Math.max(0, bp.maxBypasses - used);
      bypassInfo = {
        allowed: remaining > 0,
        remaining,
        durationMinutes: bp.bypassDurationMinutes
      };
    }
  }
  return { result, config: siteConfig, bypassInfo };
}
async function addNavEntry(url, configs) {
  const hostname = extractHostname(url);
  if (!hostname) return;
  const domainPattern = findMatchingDomainPattern(hostname, configs);
  if (!domainPattern) return;
  await mutateTrackingData(domainPattern, (data) => {
    data.navEntries.push({ timestamp: Date.now() });
  });
}
function buildBlockedUrl(result, domain, originalUrl, bypassInfo) {
  const params = new URLSearchParams({
    reason: result.reason,
    domain,
    originalUrl
  });
  params.set("resetsAt", String(result.resetsAt));
  params.set("controlType", result.type);
  if (bypassInfo) {
    params.set("bypassAllowed", String(bypassInfo.allowed));
    params.set("bypassRemaining", String(bypassInfo.remaining));
    params.set("bypassDuration", String(bypassInfo.durationMinutes));
  }
  return chrome.runtime.getURL(`ui/blocked/blocked.html?${params}`);
}
function buildSpeedBumpUrl(targetUrl, delaySeconds, domain) {
  const params = new URLSearchParams({
    url: targetUrl,
    delay: String(delaySeconds),
    domain
  });
  return chrome.runtime.getURL(`ui/speed-bump/speed-bump.html?${params}`);
}

// src/background/time-tracker.ts
async function flushActiveSession(now) {
  const session = await loadActiveSession();
  if (!session) return null;
  const duration = now - session.startedAt;
  if (duration > 1e3) {
    await mutateTrackingData(session.domainPattern, (data) => {
      data.timeEntries.push({
        start: session.startedAt,
        end: now
      });
    });
  }
  await clearActiveSession();
  return session.domainPattern;
}
async function startSession(tabId, domainPattern, now) {
  await flushActiveSession(now);
  await saveActiveSession({
    tabId,
    domainPattern,
    startedAt: now
  });
}
async function onTabActivated(tabId, configs, now) {
  await flushActiveSession(now);
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url) return;
    const hostname = extractHostname(tab.url);
    if (!hostname) return;
    const domainPattern = findMatchingDomainPattern(hostname, configs);
    if (!domainPattern) return;
    await startSession(tabId, domainPattern, now);
  } catch {
  }
}
async function onWindowFocusChanged(windowId, configs, now) {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await flushActiveSession(now);
    return;
  }
  try {
    const tabs = await chrome.tabs.query({ active: true, windowId });
    if (tabs.length > 0 && tabs[0].id !== void 0) {
      await onTabActivated(tabs[0].id, configs, now);
    }
  } catch {
    await flushActiveSession(now);
  }
}
async function onTabRemoved(tabId, now) {
  const session = await loadActiveSession();
  if (session && session.tabId === tabId) {
    await flushActiveSession(now);
  }
}
async function onNavigationCommitted(tabId, url, configs, now) {
  const session = await loadActiveSession();
  const hostname = extractHostname(url);
  const newDomain = hostname ? findMatchingDomainPattern(hostname, configs) : null;
  if (session && session.tabId === tabId) {
    if (newDomain !== session.domainPattern) {
      await flushActiveSession(now);
      if (newDomain) {
        await startSession(tabId, newDomain, now);
      }
    }
    return;
  }
  if (newDomain) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.active) {
        await startSession(tabId, newDomain, now);
      }
    } catch {
    }
  }
}
async function heartbeat(configs, now) {
  const session = await loadActiveSession();
  if (!session) return;
  await flushActiveSession(now);
  try {
    const tab = await chrome.tabs.get(session.tabId);
    if (tab.active && tab.url) {
      const hostname = extractHostname(tab.url);
      if (hostname) {
        const domain = findMatchingDomainPattern(hostname, configs);
        if (domain) {
          await startSession(session.tabId, domain, now);
        }
      }
    }
  } catch {
  }
}
async function recoverOrphanedSession(now) {
  const session = await loadActiveSession();
  if (!session) return;
  const age = now - session.startedAt;
  if (age > ORPHAN_SESSION_THRESHOLD_MS) {
    const boundedEnd = session.startedAt + ORPHAN_SESSION_THRESHOLD_MS;
    await mutateTrackingData(session.domainPattern, (data) => {
      data.timeEntries.push({
        start: session.startedAt,
        end: boundedEnd
      });
    });
    await clearActiveSession();
  }
}

// src/background/alarm-handler.ts
function setupAlarms() {
  chrome.alarms.create(ALARMS.HEARTBEAT, {
    periodInMinutes: HEARTBEAT_INTERVAL_MINUTES
  });
}
function handleAlarm(alarm, getConfigs2) {
  if (alarm.name === ALARMS.HEARTBEAT) {
    const now = Date.now();
    getConfigs2().then(async (configs) => {
      await heartbeat(configs, now);
      await pruneTrackingData(configs, now);
    });
  }
}
function computeMaxWindow(configs) {
  let maxWindow = 120;
  for (const config of configs) {
    for (const control of config.controls) {
      if (control.type === "time-limit" || control.type === "nav-frequency") {
        maxWindow = Math.max(maxWindow, control.windowMinutes);
      }
      if (control.bypass) {
        maxWindow = Math.max(maxWindow, control.bypass.windowMinutes);
      }
    }
  }
  return Math.ceil(maxWindow * 1.1);
}
async function pruneTrackingData(configs, now) {
  const maxWindow = computeMaxWindow(configs);
  const store = await loadTrackingStore();
  let anyChanged = false;
  for (const [domain, data] of Object.entries(store)) {
    const prunedTime = pruneTimeEntries(data.timeEntries, maxWindow, now);
    const prunedNav = pruneNavEntries(data.navEntries, maxWindow, now);
    let bypassChanged = false;
    const prunedBypasses = { ...data.bypasses };
    const cutoff = now - minutesToMs(maxWindow);
    for (const [type, entries] of Object.entries(prunedBypasses)) {
      if (entries) {
        const valid = entries.filter((e) => e.expiresAt > cutoff);
        if (valid.length !== entries.length) {
          prunedBypasses[type] = valid;
          bypassChanged = true;
        }
      }
    }
    const timeChanged = prunedTime.length !== data.timeEntries.length;
    const navChanged = prunedNav.length !== data.navEntries.length;
    if (timeChanged || navChanged || bypassChanged) {
      store[domain] = {
        timeEntries: prunedTime,
        navEntries: prunedNav,
        bypasses: prunedBypasses
      };
      anyChanged = true;
    }
  }
  if (anyChanged) {
    await saveTrackingStore(store);
  }
}

// src/background/service-worker.ts
initControls();
var cachedConfigs = null;
async function getConfigs() {
  if (!cachedConfigs) {
    cachedConfigs = await loadSiteConfigs();
  }
  return cachedConfigs;
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes["bastion_site_configs"]) {
    cachedConfigs = null;
    registerDegradationContentScripts();
  }
});
async function registerDegradationContentScripts() {
  try {
    await chrome.scripting.unregisterContentScripts({ ids: ["bastion-degradation"] });
  } catch {
  }
  const configs = await getConfigs();
  const patterns = [];
  for (const c of configs) {
    if (!c.enabled) continue;
    const hasDegradation = c.controls.some(
      (ctrl) => ctrl.type === "degradation" && ctrl.enabled
    );
    if (!hasDegradation) continue;
    const domain = c.domainPattern;
    if (domain.startsWith("*.")) {
      patterns.push(`*://${domain}/*`);
    } else {
      patterns.push(`*://${domain}/*`);
      patterns.push(`*://*.${domain}/*`);
    }
  }
  if (patterns.length === 0) return;
  try {
    await chrome.scripting.registerContentScripts([{
      id: "bastion-degradation",
      matches: patterns,
      js: ["content/degradation.js"],
      runAt: "document_idle"
    }]);
  } catch (e) {
    console.error("Failed to register content scripts:", e);
  }
}
var pendingRedirects = /* @__PURE__ */ new Set();
chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
  if (details.frameId !== 0) return;
  const url = details.url;
  if (url.startsWith(chrome.runtime.getURL(""))) return;
  const hostname = extractHostname(url);
  if (hostname) {
    const configs2 = await getConfigs();
    const domainPattern = findMatchingDomainPattern(hostname, configs2);
    if (domainPattern && await hasClearance(domainPattern)) return;
  }
  const configs = await getConfigs();
  const evaluation = await handleNavigation(url, configs);
  if (!evaluation) return;
  const { result, config, bypassInfo } = evaluation;
  let redirectUrl;
  if (result.action === "block") {
    redirectUrl = buildBlockedUrl(result, config.domainPattern, url, bypassInfo);
  } else if (result.action === "speed-bump") {
    redirectUrl = buildSpeedBumpUrl(
      url,
      result.delaySeconds,
      config.domainPattern
    );
  } else {
    return;
  }
  pendingRedirects.add(details.tabId);
  chrome.tabs.update(details.tabId, { url: redirectUrl }).catch(() => {
    pendingRedirects.delete(details.tabId);
  });
});
chrome.webNavigation.onCommitted.addListener(async (details) => {
  if (details.frameId !== 0) return;
  if (details.url.startsWith(chrome.runtime.getURL(""))) return;
  if (pendingRedirects.has(details.tabId)) {
    pendingRedirects.delete(details.tabId);
    return;
  }
  const configs = await getConfigs();
  await addNavEntry(details.url, configs);
  await onNavigationCommitted(details.tabId, details.url, configs, Date.now());
});
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  const configs = await getConfigs();
  await onTabActivated(activeInfo.tabId, configs, Date.now());
});
chrome.tabs.onRemoved.addListener(async (tabId) => {
  await onTabRemoved(tabId, Date.now());
});
chrome.windows.onFocusChanged.addListener(async (windowId) => {
  const configs = await getConfigs();
  await onWindowFocusChanged(windowId, configs, Date.now());
});
chrome.alarms.onAlarm.addListener((alarm) => {
  handleAlarm(alarm, getConfigs);
});
chrome.runtime.onMessage.addListener(
  (message, _sender, sendResponse) => {
    switch (message.type) {
      case "speed-bump-cleared": {
        const now = Date.now();
        addClearance({
          domain: message.domain,
          clearedAt: now,
          expiresAt: now + SPEED_BUMP_CLEARANCE_TTL_MS
        }).then(() => sendResponse({ ok: true }));
        return true;
      }
      case "activate-bypass": {
        recordBypass(message.domain, message.controlType, message.durationMinutes).then(() => sendResponse({ ok: true }));
        return true;
      }
      case "check-degradation": {
        (async () => {
          const configs = await getConfigs();
          const siteConfig = findMatchingSiteConfig(message.url, configs);
          if (!siteConfig) {
            sendResponse({ degrade: false });
            return;
          }
          const tracking = await getTrackingData(siteConfig.domainPattern);
          const now = Date.now();
          const result = evaluateControls(siteConfig, tracking, now);
          if (result.action === "degrade") {
            sendResponse({ degrade: true, effect: result.degradeEffect });
          } else {
            sendResponse({ degrade: false });
          }
        })();
        return true;
      }
    }
    return false;
  }
);
chrome.runtime.onInstalled.addListener(() => {
  setupAlarms();
  console.log("Bastion extension installed");
});
recoverOrphanedSession(Date.now());
setupAlarms();
registerDegradationContentScripts();
console.log("Bastion service worker initialized");
//# sourceMappingURL=service-worker.js.map
